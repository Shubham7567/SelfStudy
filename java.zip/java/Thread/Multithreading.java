class PrimeNo{
    double no=2;

    public double setNo(){
        return no++;
    }

    public double getNo(){
        return no;
    }
}

class Prime implements Runnable{
    PrimeNo p;
    double divisor=2;
    boolean flag;

    Prime(PrimeNo prime){
        this.p = prime;
        Thread t = new Thread(this);
        t.start();
    }

    public synchronized void run(){
        try{
            while(true){
                flag=true;
                  double no = p.setNo();
                  while(divisor <= Math.sqrt(no)){
                    if(no % divisor == 0){
                        flag = false;
                        break;
                    }
                    divisor++;
                  }
                  if(flag){
                      System.out.println("Prime - " + no);
                  }
                  if(no == 79){
                      
                  }
                  divisor = 2;
                  Thread.sleep(300);
            }
        }catch(InterruptedException e){

        }
    }
}

class Th1 implements Runnable{
    PrimeNo p;
    Th1(PrimeNo primeNo){
        p = primeNo;
        Thread t1 = new Thread(this);
        t1.start();
    }
    public synchronized void run(){
        double no = p.getNo();
        try{
            while(no != 0){
                System.out.println("Thread 1 - " + no);
                Thread.sleep(200);
                if(no == 13){
                    wait();
                }
                no = p.getNo();
            }
        }catch(InterruptedException e){

        }
    }
}

class Multithreading {
    public static void main(String[] args){
        PrimeNo primeNo = new PrimeNo();
        new Prime(primeNo); 
        new Th1(primeNo);  
    }
}
