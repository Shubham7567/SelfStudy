package bank;

import bank.Penalty;

public class CurrentAccount extends Account {
    private static final long minimum_balance = 10_000;
    private Penalty penalty = Penalty.DEFAULT_PENALTY;
    public CurrentAccount(long acno,String n)
}
