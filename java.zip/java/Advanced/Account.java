package bank;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;

public abstract class Account implements Comparable<Account>{
    private long account_number;
    private String name;
    private long balance;
    
}
