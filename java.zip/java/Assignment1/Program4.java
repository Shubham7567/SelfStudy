class Program4 {
    public static void main(String[] args){
        float x;
        x =1.25f;
        System.out.println(x);
    }    
}