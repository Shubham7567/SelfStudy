class Program14 {
    public static void main(String[] args){
        int bit_mask = 0x000F;
        int val = 0x2222;
        System.out.println(val & bit_mask);
    }    
}
