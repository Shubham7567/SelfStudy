class Program2 {
    public static void main(String[] args){
        for(int index=0;index<args.length;index++){
            System.out.println(args[index]);
        }
    }
}
