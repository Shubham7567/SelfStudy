import java.io.IOException;

class Program3 {
    public static void main(String[] args) throws IOException{
        float no1,no2;
        no1 = 24.342f;
        no2 = 22.4321f;
        System.out.println(no1 + " + " + no2 + " = " + (no1+no2));//for addition
        System.out.println(no1 + " * " + no2 + " = " + (no1*no2));//for multiplication
        System.out.println(no1 + " / " + no2 + " = " + (no1/no2));//for division
        System.out.println(no1 + " - " + no2 + " = " + (no1-no2));//for substraction
    }
}
